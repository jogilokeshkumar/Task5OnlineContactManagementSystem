package com.example.OnlineContactManagementSystem;

import org.springframework.boot.SpringApplication;

public class OnlineContactManagementSystemApplication {
    public static void main(String[] args) {
        SpringApplication.run(OnlineContactManagementSystemApplication.class, args);
    }
}
